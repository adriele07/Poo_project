# Modelo User não é mais necessário pois usamos JSON, mas pode-se manter funções utilitárias se desejar.
