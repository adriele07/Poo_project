# __init__.py para models (se necessário)
