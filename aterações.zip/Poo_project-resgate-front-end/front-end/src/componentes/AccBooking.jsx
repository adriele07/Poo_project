import React from 'react'

const AccBooking = () => {
  return (
    <div>AccBooking</div>
  )
}

export default AccBooking